package exception1;

public class Exception01P348 {

	public static void main(String[] args) {
		// 예외 발생 케이스 1.
		// 하드웨어에는 문제가 없지만 코드상 문법에 문제가 있는 경우
		// 이를 컴파일러 체크 예외라고 부릅니다.
		// 컴파일러 체크 예외는 아래줄 제일 왼쪽과 같이 에러마크가 뜹니다.
		//in a = 50;

	}

}
