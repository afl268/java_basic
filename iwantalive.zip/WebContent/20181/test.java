import java.util.Random;
import java.util.Scanner;

public class test {
public static void main(String [] args) {
	
	
	static int[] initbArray() {
		
	
	int number, input_number;
	Random rand = new Random();
	Scanner scan = new Scanner(System.in);
	int bArray[] = new int[3];
			int mAraay[] = new int[3];
			int user = s.nextInt();
			int c_n1 , c_n2 , c_n3;
			number = rand.nextInt(9)+1;
	}
	
	
	Scanner user = new Scanner(System.in);
	System.out.println("숫자입력);"
	int user = s.nextInt();
	int u_n1, u_n2, u_n3;
	
	
	int s=0;
	int b=0;
	if (c_n1 == u_n1 , c_n2 == u_n2 , c_u3 == u_n3) {
		s++;
    }
    else if(c_n1 == u_n2 , c_n1 == u_n3 ,  c_n2 == u_n3 ,  c_n2 == u_n1 , c_n3 == u_n1 , c_n3 == u_n2) { 
    	b++; 	
    }



System.out.println(s+"스트라이크"+b"볼");
}
}